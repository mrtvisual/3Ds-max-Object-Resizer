macroScript ObjResizer category:"mrtTools" tooltip:"Obj Resizer"
(
    global mrt_MeasureDims
    global mrt_MeasureDims_Content
    local iniFile = (getDir #plugcfg) + "\\mrt_obj_resizer_layout.ini"
    
    -- =========================================================================
    -- CORE LOGIC STRUCT
    -- =========================================================================
    struct mrt_ObjResizerLogic_Struct
    (
        fn getMainNode objs = (
            local bestNode = objs[1]
            local maxVol = -1.0
            for n in objs do (
                local d = n.max - n.min
                local vol = d.x * d.y * d.z
                if vol > maxVol do (
                    maxVol = vol
                    bestNode = n
                )
            )
            return bestNode
        ),
        
        fn getPreciseBounds objs coordSysState = (
            local wMin = [0,0,0], wMax = [0,0,0]
            local wX = 0.0, wY = 0.0, wZ = 0.0
            local lMin = [0,0,0], lMax = [0,0,0]
            local snapX = 0.0, snapY = 0.0, snapZ = 0.0
            
            if objs.count > 0 do (
                wMin = [1e9,1e9,1e9]; wMax = [-1e9,-1e9,-1e9]
                for obj in objs do (
                    wMin.x = amin wMin.x obj.min.x; wMin.y = amin wMin.y obj.min.y; wMin.z = amin wMin.z obj.min.z
                    wMax.x = amax wMax.x obj.max.x; wMax.y = amax wMax.y obj.max.y; wMax.z = amax wMax.z obj.max.z
                )
                wX = wMax.x - wMin.x
                wY = wMax.y - wMin.y
                wZ = wMax.z - wMin.z
                
                if coordSysState == 1 then (
                    snapX = wX; snapY = wY; snapZ = wZ
                    lMin = wMin; lMax = wMax
                ) else (
                    lMin = [1e9,1e9,1e9]; lMax = [-1e9,-1e9,-1e9]
                    
                    local topNodes = #()
                    for obj in objs do (
                        if obj.parent == undefined or (findItem objs obj.parent == 0) do appendIfUnique topNodes obj
                    )
                    if topNodes.count == 0 do topNodes = objs
                    
                    local mainNode = getMainNode topNodes
                    local tm = mainNode.transform
                    local refTM = matrix3 (normalize tm.row1) (normalize tm.row2) (normalize tm.row3) tm.pos
                    
                    for obj in objs do (
                        local bb = nodeGetBoundingBox obj refTM
                        lMin.x = amin lMin.x bb[1].x; lMin.y = amin lMin.y bb[1].y; lMin.z = amin lMin.z bb[1].z
                        lMax.x = amax lMax.x bb[2].x; lMax.y = amax lMax.y bb[2].y; lMax.z = amax lMax.z bb[2].z
                    )
                    local lX = lMax.x - lMin.x
                    local lY = lMax.y - lMin.y
                    local lZ = lMax.z - lMin.z
                    
                    local tol = 0.005
                    local wDims = #(wX, wY, wZ)
                    
                    snapX = lX
                    snapY = lY
                    snapZ = lZ
                    
                    for wd in wDims do if abs(lX - wd) < tol do snapX = wd
                    for wd in wDims do if abs(lY - wd) < tol do snapY = wd
                    for wd in wDims do if abs(lZ - wd) < tol do snapZ = wd
                )
            )
            return #(lMin, lMax, snapX, snapY, snapZ)
        ),

        fn applySmartResetXForm node coordSysState = (
            if isGroupHead node then (
                try(ResetScale node)catch()
                local wasOpen = isOpenGroupHead node
                if not wasOpen do setGroupOpen node true
                for child in node.children do applySmartResetXForm child coordSysState
                if not wasOpen do setGroupOpen node false
            ) 
            else if superClassOf node == Shape then (
                if coordSysState == 1 then try(ResetXForm node)catch()
                else try(ResetScale node)catch()
                try(convertToSplineShape node)catch()
            )
            else if canConvertTo node Editable_Poly do (
                if coordSysState == 1 then try(ResetXForm node)catch()
                else try(ResetScale node)catch()
                try(convertToPoly node)catch()
            )
        ),
        
        fn alignPivotTo objs axis state pbControl = (
            if objs.count == 0 do return false
            disableSceneRedraw()
            suspendEditing()
            try (
                undo "Align Pivot" on (
                    local bbMin = [1e9,1e9,1e9]
                    local bbMax = [-1e9,-1e9,-1e9]
                    local total = objs.count
                    for i = 1 to total do (
                        local obj = objs[i]
                        bbMin.x = amin bbMin.x obj.min.x; bbMin.y = amin bbMin.y obj.min.y; bbMin.z = amin bbMin.z obj.min.z
                        bbMax.x = amax bbMax.x obj.max.x; bbMax.y = amax bbMax.y obj.max.y; bbMax.z = amax bbMax.z obj.max.z
                    )
                    local c = (bbMin + bbMax) / 2.0
                    for i = 1 to total do (
                        local obj = objs[i]
                        local newP = obj.pivot
                        if axis == #x or axis == #all do (
                            if state == 1 do newP.x = bbMin.x; if state == 3 do newP.x = bbMax.x
                            if state == 2 do newP.x = c.x; if state == 4 do newP.x = 0.0
                        )
                        if axis == #y or axis == #all do (
                            if state == 1 do newP.y = bbMin.y; if state == 3 do newP.y = bbMax.y
                            if state == 2 do newP.y = c.y; if state == 4 do newP.y = 0.0
                        )
                        if axis == #z or axis == #all do (
                            if state == 1 do newP.z = bbMin.z; if state == 3 do newP.z = bbMax.z
                            if state == 2 do newP.z = c.z; if state == 4 do newP.z = 0.0
                        )
                        obj.pivot = newP
                        if pbControl != undefined and (mod i 5 == 0 or i == total) do pbControl.value = (i as float / total) * 100.0
                    )
                )
            ) catch (
                format "Error in alignPivotTo: %\n" (getCurrentException())
            )
            resumeEditing()
            enableSceneRedraw()
            try(toolMode.pivotCenter())catch()
            redrawViews()
            if pbControl != undefined do pbControl.value = 0
            return true
        ),
        
        fn applySmartVertexMoveGroup objs scaleFactor activeAnchor lastChangedAxis coordSysState = (
            local bbData = getPreciseBounds objs coordSysState
            local bbMin = bbData[1]
            local bbMax = bbData[2]
            local lCenter = (bbMin + bbMax) / 2.0
            local curDim = bbMax - bbMin
            
            local dX = curDim.x * scaleFactor.x - curDim.x
            local dY = curDim.y * scaleFactor.y - curDim.y
            local dZ = curDim.z * scaleFactor.z - curDim.z
            
            local refTM = matrix3 1
            if coordSysState == 2 do (
                local topNodes = #()
                for obj in objs do (
                    if obj.parent == undefined or (findItem objs obj.parent == 0) do appendIfUnique topNodes obj
                )
                if topNodes.count == 0 do topNodes = objs
                
                local mainNode = getMainNode topNodes
                local tm = mainNode.transform
                refTM = matrix3 (normalize tm.row1) (normalize tm.row2) (normalize tm.row3) tm.pos
            )
            local invTM = inverse refTM
            
            theHold.Begin()
            for obj in objs do (
                try(convertToPoly obj)catch(continue)
                if isProperty obj "preserveUVs" do obj.preserveUVs = true
                
                local numVerts = polyOp.getNumVerts obj
                if numVerts == 0 do continue
                
                local ptsToSet = #()
                for v = 1 to numVerts do (
                    local wp = polyOp.getVert obj v
                    local p = wp * invTM
                    local pNew = copy p
                    if dZ != 0 and curDim.z > 0.001 do (
                        if activeAnchor == 1 then ( if p.z < lCenter.z do pNew.z -= dZ )
                        else if activeAnchor == 2 then ( if p.z > lCenter.z do pNew.z += dZ )
                        else ( if p.z > lCenter.z then pNew.z += (dZ / 2.0) else pNew.z -= (dZ / 2.0) )
                    )
                    if dX != 0 and curDim.x > 0.001 do (
                        if activeAnchor == 3 then ( if p.x > lCenter.x do pNew.x += dX )
                        else if activeAnchor == 4 then ( if p.x < lCenter.x do pNew.x -= dX )
                        else ( if p.x > lCenter.x then pNew.x += (dX / 2.0) else pNew.x -= (dX / 2.0) )
                    )
                    if dY != 0 and curDim.y > 0.001 do (
                        if activeAnchor == 3 then ( if p.y > lCenter.y do pNew.y += dY )
                        else if activeAnchor == 4 then ( if p.y < lCenter.y do pNew.y -= dY )
                        else ( if p.y > lCenter.y then pNew.y += (dY / 2.0) else pNew.y -= (dY / 2.0) )
                    )
                    append ptsToSet (pNew * refTM)
                )
                for v = 1 to numVerts do polyOp.setVert obj v ptsToSet[v]
                free ptsToSet
            )
            theHold.Accept "Smart Vertex Move"
        ),

        fn applySmartVertexMoveIndiv obj scaleFactor activeAnchor lastChangedAxis coordSysState = (
            applySmartVertexMoveGroup #(obj) scaleFactor activeAnchor lastChangedAxis coordSysState
        ),
        
        fn applyScale objs targetValues exactValues activeAnchor lastChangedAxis resetXForm coordSysState pbControl resizeMethod resizeMode preserveFFD = (
            if objs.count == 0 do return false
            try (
                undo "Resize Object" on 
                (
                    local topNodes = #()
                    for obj in objs do (
                        if obj.parent == undefined or (findItem objs obj.parent == 0) do appendIfUnique topNodes obj
                    )
                    local total = topNodes.count
                    
                    local bbData = getPreciseBounds objs coordSysState
                    local groupMin = bbData[1]
                    local groupMax = bbData[2]
                    
                    local refTM = matrix3 1
                    local mainNode = undefined
                    if coordSysState == 2 do (
                        mainNode = getMainNode topNodes
                        local tm = mainNode.transform
                        refTM = matrix3 (normalize tm.row1) (normalize tm.row2) (normalize tm.row3) tm.pos
                    )
                    
                    if resizeMethod == 1 then (
                        if resizeMode == 1 then (
                            for i = 1 to total do (
                                local obj = topNodes[i]
                                local objBB = getPreciseBounds #(obj) coordSysState
                                local bMin = objBB[1]
                                local bMax = objBB[2]
                                local oX = objBB[3]; local oY = objBB[4]; local oZ = objBB[5]
                                local oSX = if oX > 0.001 then (targetValues.x / oX) else 1.0
                                local oSY = if oY > 0.001 then (targetValues.y / oY) else 1.0
                                local oSZ = if oZ > 0.001 then (targetValues.z / oZ) else 1.0
                                
                                local pX = (bMin.x + bMax.x) / 2.0
                                local pY = (bMin.y + bMax.y) / 2.0
                                local pZ = (bMin.z + bMax.z) / 2.0
                                
                                case activeAnchor of (
                                    1: pZ = bMax.z
                                    2: pZ = bMin.z
                                    3: pX = bMin.x
                                    4: pX = bMax.x
                                )
                                
                                local lTM = matrix3 1
                                if coordSysState == 2 do (
                                    local ltm_base = obj.transform
                                    lTM = matrix3 (normalize ltm_base.row1) (normalize ltm_base.row2) (normalize ltm_base.row3) ltm_base.pos
                                )
                                
                                local pivotPt = [pX, pY, pZ]
                                if coordSysState == 2 do pivotPt = pivotPt * lTM
                                lTM.pos = pivotPt
                                
                                in coordsys lTM about lTM scale obj [oSX, oSY, oSZ]
                                if pbControl != undefined do pbControl.value = (i as float / total) * 100.0
                            )
                        ) else (
                            local sX = if exactValues.x > 0.001 then (targetValues.x / exactValues.x) else 1.0
                            local sY = if exactValues.y > 0.001 then (targetValues.y / exactValues.y) else 1.0
                            local sZ = if exactValues.z > 0.001 then (targetValues.z / exactValues.z) else 1.0
                            local pX = (groupMin.x + groupMax.x) / 2.0
                            local pY = (groupMin.y + groupMax.y) / 2.0
                            local pZ = (groupMin.z + groupMax.z) / 2.0
                            
                            case activeAnchor of (
                                1: pZ = groupMax.z; 2: pZ = groupMin.z
                                3: pX = groupMin.x
                                4: pX = groupMax.x
                            )
                            local pivotPt = [pX, pY, pZ]
                            if coordSysState == 2 do pivotPt = pivotPt * refTM
                            refTM.pos = pivotPt
                            
                            in coordsys refTM about refTM (
                                for i = 1 to total do (
                                    scale topNodes[i] [sX, sY, sZ]
                                    if pbControl != undefined do pbControl.value = (i as float / total) * 100.0
                                )
                            )
                        )
                    ) else if resizeMethod == 2 then (
                        max modify mode
                        local lx = 0.5, ly = 0.5, lz = 0.5
                        case activeAnchor of (
                            1: lz = 1.0; 2: lz = 0.0
                            3: lx = 0.0
                            4: lx = 1.0
                        )
                        local lAnchor = [lx, ly, lz]
                        
                        if resizeMode == 2 then (
                            local sX = if exactValues.x > 0.001 then (targetValues.x / exactValues.x) else 1.0
                            local sY = if exactValues.y > 0.001 then (targetValues.y / exactValues.y) else 1.0
                            local sZ = if exactValues.z > 0.001 then (targetValues.z / exactValues.z) else 1.0
                            select topNodes
                            local ffdMod = FFD_2x2x2()
                            modPanel.addModToSelection ffdMod
                            animateVertex ffdMod #all
                            for c = 1 to 8 do (
                                local propName = ("control_point_" + c as string) as name
                                local cp = getProperty ffdMod propName
                                cp.x = lAnchor.x + (cp.x - lAnchor.x) * sX
                                cp.y = lAnchor.y + (cp.y - lAnchor.y) * sY
                                cp.z = lAnchor.z + (cp.z - lAnchor.z) * sZ
                                setProperty ffdMod propName cp
                            )
                            if not preserveFFD do for obj in topNodes do try(convertToPoly obj)catch(try(convertToMesh obj)catch())
                        ) else (
                            for i = 1 to total do (
                                local obj = topNodes[i]
                                select obj
                                local objBB = getPreciseBounds #(obj) coordSysState
                                local oX = objBB[3]; local oY = objBB[4]; local oZ = objBB[5]
                                local oSX = if oX > 0.001 then (targetValues.x / oX) else 1.0
                                local oSY = if oY > 0.001 then (targetValues.y / oY) else 1.0
                                local oSZ = if oZ > 0.001 then (targetValues.z / oZ) else 1.0
                                
                                local ffdMod = FFD_2x2x2()
                                modPanel.addModToSelection ffdMod
                                animateVertex ffdMod #all
                                for c = 1 to 8 do (
                                    local propName = ("control_point_" + c as string) as name
                                    local cp = getProperty ffdMod propName
                                    cp.x = lAnchor.x + (cp.x - lAnchor.x) * oSX
                                    cp.y = lAnchor.y + (cp.y - lAnchor.y) * oSY
                                    cp.z = lAnchor.z + (cp.z - lAnchor.z) * oSZ
                                    setProperty ffdMod propName cp
                                )
                                if not preserveFFD do try(convertToPoly obj)catch(try(convertToMesh obj)catch())
                                if pbControl != undefined do pbControl.value = (i as float / total) * 100.0
                            )
                        )
                        select topNodes
                    ) else if resizeMethod == 3 then (
                        if resizeMode == 2 then (
                            local sX = if exactValues.x > 0.001 then (targetValues.x / exactValues.x) else 1.0
                            local sY = if exactValues.y > 0.001 then (targetValues.y / exactValues.y) else 1.0
                            local sZ = if exactValues.z > 0.001 then (targetValues.z / exactValues.z) else 1.0
                            applySmartVertexMoveGroup topNodes [sX, sY, sZ] activeAnchor lastChangedAxis coordSysState
                        ) else (
                            for i = 1 to total do (
                                local obj = topNodes[i]
                                local objBB = getPreciseBounds #(obj) coordSysState
                                local oX = objBB[3]; local oY = objBB[4]; local oZ = objBB[5]
                                local oSX = if oX > 0.001 then (targetValues.x / oX) else 1.0
                                local oSY = if oY > 0.001 then (targetValues.y / oY) else 1.0
                                local oSZ = if oZ > 0.001 then (targetValues.z / oZ) else 1.0
                                applySmartVertexMoveIndiv obj [oSX, oSY, oSZ] activeAnchor lastChangedAxis coordSysState
                                if pbControl != undefined do pbControl.value = (i as float / total) * 100.0
                            )
                        )
                    )
                    
                    if resetXForm and not preserveFFD do (
                        for i = 1 to total do applySmartResetXForm topNodes[i] coordSysState
                    )
                )
            ) catch (
                format "Error in applyScale: %\n" (getCurrentException())
            )
            redrawViews()
            if pbControl != undefined do pbControl.value = 0
            gc light:true
            return true
        )
    )
    
    local mrt_ObjResizer = mrt_ObjResizerLogic_Struct()
    
    -- =========================================================================
    -- SCROLLABLE CONTENT ROLLOUT (Absolute Positioning with GroupBoxes)
    -- =========================================================================
    rollout mrt_MeasureDims_Content "Obj Resizer Content"
    (
        local storedSelection = #()
        local storedSnapState = false
        local storedSnapType = #3D
        local realX = 0.0, realY = 0.0, realZ = 0.0
        local lastChangedAxis = undefined
        local activeAnchor = 0
        
        timer tmr_plane "Timer" interval:500 active:false
        
        -- General Settings Group
        groupBox grp_mode "General Settings" pos:[10,5] width:330 height:175
        label lbl_modeTitle "Resize Mode:" pos:[20,25]
        radiobuttons rdo_resizeMode labels:#("Individual", "As One Group") default:2 pos:[130,25] columns:2
        
        label lbl_methodTitle "Resize Strategy:" pos:[20,60]
        radiobuttons rdo_resizeMethod labels:#("Standard Scale", "FFD 2x2x2", "Smart Vertex Move") default:1 pos:[130,60] columns:1
        
        checkbox chk_preserveFFD "Preserve FFD Stack" pos:[150,116] checked:true visible:false
        
        label lbl_coordTitle "Coordinate System:" pos:[20,145]
        radiobuttons rdo_coordSys labels:#("World", "Local") default:1 pos:[135,145] columns:2
        
        -- Dimensions Group
        groupBox grp_dims "Dimensions (XYZ)" pos:[10,185] width:330 height:220
        button btnRead "Get Real Dimensions" width:310 height:30 pos:[20,205] tooltip:"Reads the exact bounding box of the selected object(s)."
        
        label lbl_axisX "X:" pos:[20,248]
        edittext edtX "" readOnly:true width:80 pos:[35,245]
        label lbl_arrX ">>" pos:[121,248]
        spinner spn_newX "" type:#float range:[0,1e8,0] scale:0.1 fieldwidth:80 pos:[140,245]
        label lbl_unitX "units" pos:[235,246] enabled:false
        
        label lbl_axisY "Y:" pos:[20,283]
        edittext edtY "" readOnly:true width:80 pos:[35,280]
        label lbl_arrY ">>" pos:[121,283]
        spinner spn_newY "" type:#float range:[0,1e8,0] scale:0.1 fieldwidth:80 pos:[140,280]
        label lbl_unitY "units" pos:[235,281] enabled:false
        
        label lbl_axisZ "Z:" pos:[20,318]
        edittext edtZ "" readOnly:true width:80 pos:[35,315]
        label lbl_arrZ ">>" pos:[121,318]
        spinner spn_newZ "" type:#float range:[0,1e8,0] scale:0.1 fieldwidth:80 pos:[140,315]
        label lbl_unitZ "units" pos:[235,316] enabled:false
        
        checkbutton btn_lock "Lock" width:65 height:90 pos:[265,245] tooltip:"Toggle Proportional Lock"
        
        label lbl_or "- OR -" pos:[160,350]
        checkbutton btnCreateHelper "Draw Plane" width:130 height:25 pos:[32,370] tooltip:"Draw temporary Plane with AutoGrid."
        checkbutton btnPickSource "Pick Source" width:130 height:25 pos:[172,370] tooltip:"Copy dimensions from another object."
        
        -- Anchor Group
        groupBox grp_anchor "Anchor Point (Fixed Side)" pos:[10,410] width:330 height:150
        checkbutton btn_up "Top" width:60 height:30 pos:[145,435] tooltip:"Lock Top Edge"
        checkbutton btn_left "Left" width:60 height:30 pos:[75,475] tooltip:"Lock Left Edge"
        checkbutton btn_center "Center" width:60 height:30 pos:[145,475] checked:true tooltip:"Center Pivot"
        checkbutton btn_right "Right" width:60 height:30 pos:[215,475] tooltip:"Lock Right Edge"
        checkbutton btn_down "Bottom" width:60 height:30 pos:[145,515] tooltip:"Lock Bottom Edge"
        
        -- Final Actions (Moved Above Align Pivot)
        checkbox chk_resetXForm "Auto Reset XForm && Collapse" checked:true pos:[15,575]
        button btn_scale "Apply" width:330 height:35 pos:[10,600] enabled:false tooltip:"Apply the resize operation."
        progressbar pb_process width:330 height:8 pos:[10,640] color:(color 0 200 0)
        
        -- Align Pivot Group (Moved Below Apply)
        groupBox grp_align "Align Pivot" pos:[10,665] width:330 height:130
        radiobuttons rdo_pivState labels:#("Min", "Center", "Max", "Origin") pos:[105,685] columns:2
        
        button btn_pivX "X" width:60 height:28 pos:[75,720]
        button btn_pivY "Y" width:60 height:28 pos:[145,720]
        button btn_pivZ "Z" width:60 height:28 pos:[215,720]
        
        button btn_pivCenter "Center" width:95 height:28 pos:[75,755]
        button btn_pivOrigin "Origin" width:95 height:28 pos:[180,755]
        
        label lbl_copyright "Copyright (c) 2026" pos:[125,805]
        label lbl_name "Mohammad Reza Taheri" pos:[115,820]
        label lbl_email "mrt.visual@gmail.com" pos:[120,835]
        label lbl_padding "" pos:[10,855] height:20
        
        fn updateDynamicUnits = (
            local uStr = "units"
            if units.DisplayType == #generic then (
                case units.SystemType of (
                    #millimeters: uStr = "mm"; #centimeters: uStr = "cm"; #meters: uStr = "m"
                    #kilometers: uStr = "km"; #inches: uStr = "in"; #feet: uStr = "ft"
                    #miles: uStr = "mi"; default: uStr = "units"
                )
            ) else if units.DisplayType == #metric then (
                case units.MetricType of (
                    #millimeters: uStr = "mm"; #centimeters: uStr = "cm"; #meters: uStr = "m"
                    #kilometers: uStr = "km"; default: uStr = "units"
                )
            ) else if units.DisplayType == #us then (
                local usStr = units.USSType as string
                if matchPattern usStr pattern:"*in*" ignoreCase:true then uStr = "in" else uStr = "ft"
            ) else if units.DisplayType == #custom do uStr = units.CustomName
            
            lbl_unitX.text = uStr; lbl_unitY.text = uStr; lbl_unitZ.text = uStr
        )
        
        fn updateAnchor id = (
            btn_up.checked = (id == 1); btn_down.checked = (id == 2)
            btn_left.checked = (id == 3); btn_right.checked = (id == 4)
            btn_center.checked = (id == 0); activeAnchor = id
        )
        
        on btn_up changed state do updateAnchor 1
        on btn_down changed state do updateAnchor 2
        on btn_left changed state do updateAnchor 3
        on btn_right changed state do updateAnchor 4
        on btn_center changed state do updateAnchor 0

        fn readDimensions preserveStack = (
            if selection.count > 0 then (
                local bbData = #()
                if preserveStack then (
                    local selArr = selection as array
                    local topNodes = #()
                    for obj in selArr do if obj.parent == undefined or (findItem selArr obj.parent == 0) do appendIfUnique topNodes obj
                    local tempNodes = #()
                    maxOps.cloneNodes topNodes cloneType:#copy newNodes:&tempNodes
                    for n in tempNodes do mrt_ObjResizer.applySmartResetXForm n rdo_coordSys.state
                    bbData = mrt_ObjResizer.getPreciseBounds tempNodes rdo_coordSys.state
                    delete tempNodes
                ) else (
                    bbData = mrt_ObjResizer.getPreciseBounds (selection as array) rdo_coordSys.state
                )
                
                realX = (formattedPrint bbData[3] format:"0.3f") as float
                realY = (formattedPrint bbData[4] format:"0.3f") as float
                realZ = (formattedPrint bbData[5] format:"0.3f") as float
                
                edtX.text = formattedPrint realX format:"0.3f"
                edtY.text = formattedPrint realY format:"0.3f"
                edtZ.text = formattedPrint realZ format:"0.3f"
                
                spn_newX.value = realX
                spn_newY.value = realY
                spn_newZ.value = realZ
                lastChangedAxis = undefined
                btn_scale.enabled = true
                return true
            )
            btn_scale.enabled = false
            return false
        )
        
        on rdo_resizeMethod changed state do (
            chk_preserveFFD.visible = (state == 2)
            edtX.text = ""
            edtY.text = ""
            edtZ.text = ""
            spn_newX.value = 0.0
            spn_newY.value = 0.0
            spn_newZ.value = 0.0
            realX = 0.0
            realY = 0.0
            realZ = 0.0
            btn_scale.enabled = false
        )
        
        on btn_lock changed state do (
            if state then (
                btn_lock.text = "Locked"
                if lastChangedAxis != undefined do (
                    case lastChangedAxis of (
                        #x: if realX > 0 do (
                            local ratio = spn_newX.value / realX
                            spn_newY.value = realY * ratio; spn_newZ.value = realZ * ratio
                        )
                        #y: if realY > 0 do (
                            local ratio = spn_newY.value / realY
                            spn_newX.value = realX * ratio; spn_newZ.value = realZ * ratio
                        )
                        #z: if realZ > 0 do (
                            local ratio = spn_newZ.value / realZ
                            spn_newX.value = realX * ratio; spn_newY.value = realY * ratio
                        )
                    )
                )
            ) else (
                btn_lock.text = "Lock"
            )
        )
        
        on spn_newX changed val do (
            lastChangedAxis = #x
            if btn_lock.checked and realX > 0 do (
                local ratio = val / realX
                spn_newY.value = realY * ratio; spn_newZ.value = realZ * ratio
            )
        )
        on spn_newY changed val do (
            lastChangedAxis = #y
            if btn_lock.checked and realY > 0 do (
                local ratio = val / realY
                spn_newX.value = realX * ratio; spn_newZ.value = realZ * ratio
            )
        )
        on spn_newZ changed val do (
            lastChangedAxis = #z
            if btn_lock.checked and realZ > 0 do (
                local ratio = val / realZ
                spn_newX.value = realX * ratio; spn_newY.value = realY * ratio
            )
        )
        
        on btn_pivX pressed do mrt_ObjResizer.alignPivotTo (selection as array) #x rdo_pivState.state pb_process
        on btn_pivY pressed do mrt_ObjResizer.alignPivotTo (selection as array) #y rdo_pivState.state pb_process
        on btn_pivZ pressed do mrt_ObjResizer.alignPivotTo (selection as array) #z rdo_pivState.state pb_process
        on btn_pivCenter pressed do mrt_ObjResizer.alignPivotTo (selection as array) #all 2 pb_process
        on btn_pivOrigin pressed do mrt_ObjResizer.alignPivotTo (selection as array) #all 4 pb_process
        
        on rdo_coordSys changed state do (
            local targetSys = if state == 1 then #world else #local
            local currentMode = toolMode.commandMode
            if currentMode == #move or currentMode == #rotate or currentMode == #nuscale or currentMode == #uscale or currentMode == #squash or currentMode == #select then (
                toolMode.commandMode = #move; toolMode.coordsys targetSys
                toolMode.commandMode = #rotate; toolMode.coordsys targetSys
                try(toolMode.commandMode = #nuscale; toolMode.coordsys targetSys)catch()
                toolMode.commandMode = currentMode
            ) else toolMode.coordsys targetSys
            
            edtX.text = ""
            edtY.text = ""
            edtZ.text = ""
            spn_newX.value = 0.0
            spn_newY.value = 0.0
            spn_newZ.value = 0.0
            realX = 0.0
            realY = 0.0
            realZ = 0.0
            btn_scale.enabled = false
        )
        
        on btnRead pressed do (
            updateDynamicUnits()
            if selection.count == 0 then (
                btn_scale.enabled = false
                messageBox "Please select an object first." title:"Warning"
            ) else (
                local isFFDPreserve = (rdo_resizeMethod.state == 2 and chk_preserveFFD.checked)
                
                if not isFFDPreserve do (
                    undo "Pre-Reset XForm" on (
                        local selArr = selection as array
                        local topNodes = #()
                        for obj in selArr do (
                            if obj.parent == undefined or (findItem selArr obj.parent == 0) do appendIfUnique topNodes obj
                        )
                        for n in topNodes do mrt_ObjResizer.applySmartResetXForm n rdo_coordSys.state
                    )
                )
                readDimensions isFFDPreserve
            )
        )
        
        on btnCreateHelper changed state do (
            if state then (
                if selection.count > 0 do storedSelection = selection as array
                storedSnapState = snapMode.active -- ????? ????? ???? ????
                storedSnapType = snapMode.type -- ????? ??? ???? ???? (????? 2.5D)
                
                snapMode.type = #3D -- ????? ?? ???? ???????
                snapMode.active = true -- ???? ???? ????
                
                maxOps.autoGrid = true
                max create mode
                StartObjectCreation Plane
                tmr_plane.active = true
            ) else (
                maxOps.autoGrid = false
                snapMode.type = storedSnapType -- ?????????? ??? ???? ?? ???? ????
                snapMode.active = storedSnapState -- ?????????? ????? ?????/???? ?? ???? ????
                toolMode.commandMode = #select
                tmr_plane.active = false
            )
        )
        
        on tmr_plane tick do (
            if toolMode.commandMode != #create do (
                btnCreateHelper.checked = false
                maxOps.autoGrid = false
                snapMode.type = storedSnapType -- ?????????? ??? ???? ?? ???? ????
                snapMode.active = storedSnapState -- ?????????? ????? ?????/???? ?? ???? ????
                tmr_plane.active = false
            )
        )
        
        on btnPickSource changed state do (
            if state then (
                local obj = pickObject message:"Pick Source Object"
                if isValidNode obj then (
                    btnPickSource.text = obj.name
                    local bbData = mrt_ObjResizer.getPreciseBounds #(obj) rdo_coordSys.state
                    local srcX = (formattedPrint bbData[3] format:"0.3f") as float
                    local srcY = (formattedPrint bbData[4] format:"0.3f") as float
                    local srcZ = (formattedPrint bbData[5] format:"0.3f") as float
                    
                    spn_newX.value = srcX
                    spn_newY.value = srcY
                    if (superClassOf obj != Shape) and (srcZ >= 0.001) then (
                        spn_newZ.value = srcZ
                    ) else (
                        messageBox "Z axis skipped for Shape object." title:"Notice"
                    )
                    
                    lastChangedAxis = #x
                    if btn_lock.checked and realX > 0 do (
                        local ratio = spn_newX.value / realX
                        spn_newY.value = realY * ratio; spn_newZ.value = realZ * ratio
                    )
                    
                    btn_scale.enabled = true
                    
                    if storedSelection.count > 0 do (
                        local validNodes = for n in storedSelection where isValidNode n collect n
                        if validNodes.count > 0 do select validNodes
                        storedSelection = #()
                    )
                ) else (
                    btnPickSource.checked = false
                    btnPickSource.text = "Pick Source"
                )
            ) else (
                btnPickSource.text = "Pick Source"
            )
        )
        
        on btn_scale pressed do (
            if selection.count > 0 and (realX > 0 or realY > 0 or realZ > 0) then (
                if (realX > 0 and spn_newX.value == 0) or (realY > 0 and spn_newY.value == 0) or (realZ > 0 and spn_newZ.value == 0) then (
                    messageBox "Dimensions cannot be 0.0." title:"Error"
                ) else (
                    local targetValues = [spn_newX.value, spn_newY.value, spn_newZ.value]
                    local bbData = mrt_ObjResizer.getPreciseBounds (selection as array) rdo_coordSys.state
                    local exactValues = [bbData[3], bbData[4], bbData[5]]
                    
                    local isFFDPreserve = (rdo_resizeMethod.state == 2 and chk_preserveFFD.checked)
                    
                    mrt_ObjResizer.applyScale (selection as array) targetValues exactValues activeAnchor lastChangedAxis chk_resetXForm.checked rdo_coordSys.state pb_process rdo_resizeMethod.state rdo_resizeMode.state isFFDPreserve
                    
                    readDimensions isFFDPreserve
                )
            ) else messageBox "Get real dimensions first." title:"Error"
        )
    )

    -- =========================================================================
    -- MAIN PARENT ROLLOUT & TOGGLE LOGIC
    -- =========================================================================
    rollout mrt_MeasureDims "Obj Resizer" width:360 height:570
    (
        button btnDockLeft "<" width:22 height:16 align:#left Across:3 offset:[0,-2] flat:true
        label lblTitle "Obj Resizer" align:#center offset:[0, -1]
        button btnDockRight ">" width:22 height:16 align:#right offset:[0,-2] flat:true
        subRollout subRoll "" width:355 height:540 align:#center offset:[0,5]
        
        on mrt_MeasureDims open do (
            AddSubRollout mrt_MeasureDims.subRoll mrt_MeasureDims_Content
            mrt_MeasureDims_Content.updateDynamicUnits()
            if (getRefCoordSys()) == #local then mrt_MeasureDims_Content.rdo_coordSys.state = 2 else mrt_MeasureDims_Content.rdo_coordSys.state = 1
            mrt_MeasureDims_Content.rdo_resizeMethod.state = 1
            mrt_MeasureDims_Content.rdo_resizeMode.state = 2
            mrt_MeasureDims_Content.rdo_resizeMode.enabled = true
            mrt_MeasureDims_Content.chk_preserveFFD.visible = false
        )
        on mrt_MeasureDims resized size do (
            subRoll.width = size.x - 5
            subRoll.height = size.y - 30
        )
        on btnDockLeft pressed do (
            cui.dockDialogBar mrt_MeasureDims #cui_dock_left
            setINISetting iniFile "DockSettings" "State" "cui_dock_left"
        )
        on btnDockRight pressed do (
            cui.dockDialogBar mrt_MeasureDims #cui_dock_right
            setINISetting iniFile "DockSettings" "State" "cui_dock_right"
        )
        on mrt_MeasureDims close do (
            try (
                local ds = cui.getDockState mrt_MeasureDims
                if ds != undefined and ds != "" do setINISetting iniFile "DockSettings" "State" (ds as string)
            ) catch ()
        )
    )

    on isChecked return (mrt_MeasureDims != undefined and mrt_MeasureDims.isdisplayed)
    
    on execute do (
        if (mrt_MeasureDims != undefined and mrt_MeasureDims.isdisplayed) then (
            try(cui.unRegisterDialogBar mrt_MeasureDims)catch()
            try(destroyDialog mrt_MeasureDims)catch()
        ) else (
            try(cui.unRegisterDialogBar mrt_MeasureDims)catch()
            try(destroyDialog mrt_MeasureDims)catch()
            createDialog mrt_MeasureDims style:#(#style_border, #style_resizing) width:360 height:570
            cui.registerDialogBar mrt_MeasureDims minSize:[360,570] maxSize:[360,670] style:#(#cui_dock_left, #cui_dock_right, #cui_floatable)
            
            local savedState = getINISetting iniFile "DockSettings" "State"
            if savedState != "" then (
                case savedState of (
                    "cui_dock_left": cui.dockDialogBar mrt_MeasureDims #cui_dock_left
                    "cui_dock_right": cui.dockDialogBar mrt_MeasureDims #cui_dock_right
                    default: cui.floatDialogBar mrt_MeasureDims
                )
            ) else cui.dockDialogBar mrt_MeasureDims #cui_dock_right
        )
    )
)
macros.run "mrtTools" "ObjResizer"